from setuptools import setup
setup (Name = 'Delta', version = '1.0', py_modules = ['Delta'])