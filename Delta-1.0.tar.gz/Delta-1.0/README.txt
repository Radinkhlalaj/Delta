Delta program 
mathematical useful program