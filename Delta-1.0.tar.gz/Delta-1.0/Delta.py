from math import isqrt

#ax^2+bx+c=0
#Delta program by Radin Khalaj
def delta(a, b, c):
    delta = b*b-4*a*c
    if delta < 0:
        return 'No solution'
    else:
        sqd = isqrt(delta)
        aa = 2 * a
        bb = -b
        xaa = bb + sqd
        xbb = bb - sqd
        xa = xaa / aa
        xb = xbb / aa
        if xa == xb:
            return str(x) + '=' + str(xa)
        else:
            return 'x' + ' 1 = ' + str(xa)  + '\nx' + ' 2 = ' + str(xb)